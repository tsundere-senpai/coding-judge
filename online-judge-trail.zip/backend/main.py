from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import docker
import uuid
import os
import time
from fastapi.middleware.cors import CORSMiddleware
app = FastAPI()
client = docker.from_env()

# Allow frontend to communicate with backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Change "*" to specific domains if needed
    allow_credentials=True,
    allow_methods=["*"],  # Allows GET, POST, OPTIONS, etc.
    allow_headers=["*"],
)

# Define request body structure
class CodeSubmission(BaseModel):
    language: str
    code: str

LANGUAGE_CONFIG = {
    "python": {"image": "python:3.8", "cmd": "python3"},
    "cpp": {"image": "gcc:latest", "cmd": "g++ -o main main.cpp && ./main"},
}


@app.post("/submit/")
def submit_code(submission: CodeSubmission):
    language = submission.language
    code = submission.code
    print("check1:" + code)

    if language not in LANGUAGE_CONFIG:
        raise HTTPException(status_code=400, detail="Unsupported language")

    container_id = str(uuid.uuid4())
    tmp2_dir = "/tmp"  # Explicitly using host-mounted /tmp

    code_file = f"{container_id}.code"
    file_path = os.path.join(tmp2_dir, code_file)

    # Write code to the file
    with open(file_path, "w") as f:
        f.write(code)

    time.sleep(1)  # Ensure file is written before proceeding

    if not os.path.exists(file_path):
        raise Exception(f"File {file_path} was not created!")
    else:
        print(f"File was created: {file_path}")

    try:
        config = LANGUAGE_CONFIG[language]
        print(f"Host file path: {file_path}")
        print(f"Directory being mounted: {tmp2_dir}")
        print(f"Expected container path: /tmp/{code_file}")

        container = client.containers.run(
            image=config["image"],
            # command=f"/bin/sh -c 'ls /tmp && cat /tmp/{code_file}'",
            command=f"/bin/sh -c 'python3 /tmp/{code_file}'",
            volumes={tmp2_dir: {'bind': '/tmp', 'mode': 'rw'}},
            working_dir="/tmp",
            mem_limit="128m",
            cpu_period=100000,
            cpu_quota=50000,
            network_disabled=True,
            detach=True
        )

        container.wait()  # Wait for execution to finish
        result = container.logs().decode().strip()

        print("check3: " + result)
    except Exception as e:
        print("check2: " + str(e))
        return {"error": str(e)}
    time.sleep(0.5)
    finally:
        os.remove(file_path)  # Clean up the file
    return {"output": result}

